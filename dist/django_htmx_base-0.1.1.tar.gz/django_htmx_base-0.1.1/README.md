============
django-htmx-base
============

django-htmx-base is a Django app that includes a collection of classes and abstract models for django + htmx projects.

Detailed documentation is in the "docs" directory.

Quick start
-----------

1. Add "base" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...,
        "django_htmx_base",
    ]

2. Run ``python manage.py migrate`` to create the models.

3. Import classes like "BaseModel" in your apps ´models.py´ file.
